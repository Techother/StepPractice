export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { fields } = req.body;
  if (!fields) {
    return res.status(400).json({ error: "Missing fields" });
  }

  const baseId = process.env.AIRTABLE_BASE_ID;
  const table  = process.env.AIRTABLE_TABLE || "Submissions";
  const token  = process.env.AIRTABLE_TOKEN;

  if (!baseId || !token) {
    return res.status(500).json({ error: "Airtable env vars not configured" });
  }

  const airtableRes = await fetch(
    `https://api.airtable.com/v0/${baseId}/${encodeURIComponent(table)}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ fields, typecast: true })
    }
  );

  if (!airtableRes.ok) {
    const text = await airtableRes.text();
    return res.status(airtableRes.status).json({ error: text });
  }

  const data = await airtableRes.json();
  return res.status(200).json({ id: data.id });
}
